document.addEventListener('DOMContentLoaded', function () {

    // =========================================================
    // 1. إضافة أنماط CSS ديناميكية للحركات (Shake & Transitions)
    // =========================================================
    const dynamicStyle = document.createElement('style');
    dynamicStyle.innerHTML = `
        /* حركة الاهتزاز للحقول الخاطئة */
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-6px); }
            75% { transform: translateX(6px); }
        }
        /* حركة النبض للبطاقات لتنبيه المستخدم */
        @keyframes gentlePulse {
            0%, 100% { border-color: #E5E7EB; box-shadow: 0 0 0 0 rgba(108, 77, 255, 0); }
            50% { border-color: #6C4DFF; box-shadow: 0 0 10px rgba(108, 77, 255, 0.2); }
        }
        .card-pulse {
            animation: gentlePulse 1.2s ease-in-out 2;
        }
        /* حركة ظهور الحقول الإضافية */
        .role-fields {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            max-height: 0;
            overflow: hidden;
            opacity: 0;
            margin-top: 0;
        }
        .role-fields:not(.hidden) {
            max-height: 1500px; /* قيمة كبيرة للسماح بالتمدد */
            opacity: 1;
            margin-top: 20px;
        }
    `;
    document.head.appendChild(dynamicStyle);

    // =========================================================
    // 2. التبديل بين أنواع الحسابات (Account Type Switching)
    // =========================================================
    const accountCards = document.querySelectorAll('.account-type-card');
    const designerFields = document.getElementById('designerFields');
    const printShopFields = document.getElementById('printShopFields');

    accountCards.forEach(card => {
        card.addEventListener('click', function () {
            // إزالة الكلاس النشط من جميع البطاقات وإيقاف النبض
            accountCards.forEach(c => {
                c.classList.remove('active');
                c.classList.remove('card-pulse');
            });

            // إضافة الكلاس النشط للبطاقة المضغوطة مع تأثير نقرة
            this.classList.add('active');
            
            // تأثير ضغطة صغيرة عند النقر
            this.style.transform = "scale(0.96)";
            setTimeout(() => {
                this.style.transform = "";
            }, 150);

            // الحصول على نوع الحساب
            const role = this.getAttribute('data-role');

            // إخفاء جميع الحقول الإضافية أولاً
            designerFields.classList.add('hidden');
            printShopFields.classList.add('hidden');

            // إظهار الحقول المناسبة للنوع مع تأخير بسيط للسماح بإغلاق السابق
            setTimeout(() => {
                if (role === 'designer') {
                    designerFields.classList.remove('hidden');
                } else if (role === 'printshop') {
                    printShopFields.classList.remove('hidden');
                }
            }, 200);
        });
    });

    // =========================================================
    // 3. إظهار/إخفاء كلمة المرور (مع دوران الأيقونة)
    // =========================================================
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');

    togglePasswordButtons.forEach(button => {
        button.addEventListener('click', function () {
            const passwordInput = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');

            // تأثير دوران الأيقونة
            icon.style.transition = "transform 0.3s ease";
            icon.style.transform = "rotate(180deg)";

            setTimeout(() => {
                icon.style.transform = "rotate(0deg)";
            }, 300);

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });

    // =========================================================
    // 4. عداد الحروف (Character Counter) مع تغيير اللون
    // =========================================================
    const textareas = document.querySelectorAll('textarea[maxlength]');

    textareas.forEach(textarea => {
        const footer = textarea.parentElement.querySelector('.field-footer');
        if (footer) {
            // نبحث عن الـ span الذي يحتوي على الأرقام
            const counterSpan = footer.querySelector('span:last-child'); 
            if (counterSpan) {
                textarea.addEventListener('input', function () {
                    const currentLength = this.value.length;
                    const maxLength = this.getAttribute('maxlength');
                    counterSpan.textContent = `${currentLength} / ${maxLength}`;
                    
                    // إذا تجاوز النص 80% من الحد المسموح، يتغير لون العداد للأحمر
                    if (currentLength > maxLength * 0.8) {
                        counterSpan.style.color = "#EF4444";
                        counterSpan.style.fontWeight = "bold";
                    } else {
                        counterSpan.style.color = "#9CA3AF";
                        counterSpan.style.fontWeight = "normal";
                    }
                });
            }
        }
    });

    // =========================================================
    // 5. التحقق من صحة المدخلات (Form Validation)
    // =========================================================
    const registerForm = document.getElementById('registerForm');

    registerForm.addEventListener('submit', function (e) {
        e.preventDefault();

        let isValid = true;
        // جلب جميع الحقول المطلوبة داخل النموذج
        const requiredInputs = this.querySelectorAll('input[required], select[required], textarea[required]');

        requiredInputs.forEach(input => {
            // إزالة أي رسائل خطأ سابقة
            const errorMsg = input.parentElement.querySelector('.error-message');
            if (errorMsg) errorMsg.textContent = '';
            input.style.borderColor = '#E5E7EB';
            input.style.animation = '';

            if (!input.value.trim()) {
                isValid = false;
                input.style.borderColor = '#EF4444'; // لون أحمر للخطأ
                
                // تأثير اهتزاز للحقل الخاطئ (Shake effect)
                input.style.animation = "shake 0.4s ease-in-out";
                setTimeout(() => { input.style.animation = ""; }, 500);

                if (errorMsg) {
                    errorMsg.textContent = 'هذا الحقل مطلوب';
                    errorMsg.style.color = '#EF4444';
                }
            }
        });

        // التحقق من تطابق كلمة المرور
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirmPassword');
        if (password.value && confirmPassword.value && password.value !== confirmPassword.value) {
            isValid = false;
            password.style.borderColor = '#EF4444';
            confirmPassword.style.borderColor = '#EF4444';
            
            // تأثير اهتزاز لحقول كلمة المرور
            confirmPassword.style.animation = "shake 0.4s ease-in-out";
            setTimeout(() => { confirmPassword.style.animation = ""; }, 500);

            const errorMsg = confirmPassword.parentElement.querySelector('.error-message');
            if (errorMsg) {
                errorMsg.textContent = 'كلمات المرور غير متطابقة';
                errorMsg.style.color = '#EF4444';
            }
        }

        // التحقق من الموافقة على الشروط
        const termsCheckbox = document.getElementById('terms');
        if (!termsCheckbox.checked) {
            isValid = false;
            termsCheckbox.parentElement.style.color = '#EF4444';
            setTimeout(() => {
                termsCheckbox.parentElement.style.color = '';
            }, 3000);
        }

        if (isValid) {
            // تأثير نجاح على الزر
            const btn = this.querySelector('.btn-primary');
            btn.style.transform = "scale(0.95)";
            btn.style.background = "linear-gradient(to right, #00C2FF, #4ADE80)"; // تغيير اللون للأخضر للدلالة على النجاح
            
            setTimeout(() => {
                btn.style.transform = "scale(1)";
                btn.textContent = "جاري إنشاء الحساب...";
                console.log("✅ Form is valid. Ready to submit to backend.");
                // يمكنك إضافة كود إرسال البيانات إلى السيرفر هنا (Fetch API / Axios)
                
                // مثال: إعادة تعيين الزر بعد 3 ثواني
                // setTimeout(() => {
                //     btn.textContent = "إنشاء الحساب";
                //     btn.style.background = "linear-gradient(to right, #00C2FF, #6C4DFF)";
                // }, 3000);
                
            }, 300);
        } else {
            // الانتقال إلى أول حقل به خطأ لتسهيل التصحيح للمستخدم
            const firstError = this.querySelector('[style*="border-color: #EF4444"]');
            if (firstError) firstError.focus();
        }
    });

    // =========================================================
    // 6. تأثير "النبض" عند عدم اختيار حساب (لجذب الانتباه)
    // =========================================================
    // إذا مرت 2 ثانية ولم يختر المستخدم شيئاً، نضيف نبضة للبطاقة الأولى
    setTimeout(() => {
        const activeCard = document.querySelector('.account-type-card.active');
        if (!activeCard) {
            const firstCard = document.querySelector('.account-type-card');
            if (firstCard) {
                firstCard.classList.add('card-pulse');
            }
        }
    }, 2000); // بعد ثانيتين

    // =========================================================
    // 7. تحسين تجربة اختيار الحقول (Focus & Blur effects)
    // =========================================================
    const allInputs = document.querySelectorAll('input, select, textarea');
    allInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.boxShadow = "0 0 0 3px rgba(0, 194, 255, 0.1)";
        });
        input.addEventListener('blur', function() {
            this.parentElement.style.boxShadow = "none";
        });
    });

});